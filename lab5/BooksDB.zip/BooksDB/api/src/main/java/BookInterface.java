

public abstract interface BookInterface {
}
