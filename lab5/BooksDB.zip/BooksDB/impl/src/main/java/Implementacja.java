import javax.ejb.Remote;
import javax.ejb.Stateful;


public class Implementacja{


    public void foo() {

    }
}
